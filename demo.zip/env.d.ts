/// <reference types="vite/client" />
interface ImportMetaEnv {
    /** biw meta id */
    readonly VITE_BIW_META_ID: `${string}.dweb`;
}
